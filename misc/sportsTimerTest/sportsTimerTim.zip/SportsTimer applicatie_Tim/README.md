# TimerApplicatie
Timer applicatie voor parkour runners

# Gebruik van applicatie
Download het hele bestand, open de map en navigeer naar: `SportsTimer applicatie\SportsTimer Applicatie\bin\Release` en open de `SportsTimer Applicatie.exe` zorg er wel voor dat de knoppen die bij deze applicatie horen aangesloten zit aan je pc/laptop. 

# Gebruiks Handleiding (Code)
Het makkelijkste is om een versie van visual studio te hebben gedownload (community edition is gratis) nadat gedaan is kun je door het .sln bestand te openen het c# project bekijken en aanpassen. Momenteel staat er in de code bij de functie: `Form1_load` een comment die beschrijft hoe je het huidige probleem oplost met de COM-port. Houd rekening dat zodra je de applicatie aanpast en de weizigingen wilt doorvoeren je ook het programma opnieuw moet compilen. Dit kan gemakkelijk door op de F5 knop te drukken. 
